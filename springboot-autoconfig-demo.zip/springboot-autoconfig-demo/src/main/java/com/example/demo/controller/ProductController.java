package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Product;

@RestController
@RequestMapping("/products")
public class ProductController {

	@RequestMapping(method = RequestMethod.GET)
	public List<Product> getAllProducts(){
		List<Product> list = new ArrayList<>();
		
		list.add(new Product(1,"Laptop",59999.99));
		list.add(new Product(2, "phone", 24999.99));
		list.add(new Product(3, "Tablet", 14999.99));
		
		return list;
	}
}
